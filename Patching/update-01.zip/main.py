#!/usr/bin/env python
# encoding: utf-8


from __future__ import absolute_import, division, print_function, unicode_literals

import argparse
import contextlib
import errno
import hashlib
import json
import os
import subprocess
import sys
import traceback


SHEPHERD_PATH = "/root/shepherd"
SR_ROBOT_PATH = "/root/sr-robot"
PYKOKI_PATH = "/root/pykoki"
LIBKOKI_PATH = "/root/libkoki"
UPDATE_LOCK_PATH = "/root/.update-lock"
USER_CODE_PATH = "/opt/shepherd"

USB_MOUNT_POINT = "/media/RobotUSB"
FSTAB_UPDATE_COMMENT = "# robocon update 1 done"


code_is_buggy = False  # hopefully...


def info(*args):
    for line in " ".join(args).split("\n"):
        print("[I]", line)


def warn(*args):
    for line in " ".join(args).split("\n"):
        print("[I]", line)


def error(*args):
    for line in " ".join(args).split("\n"):
        print("[E]", line)


def bug(*args):
    global code_is_buggy
    code_is_buggy = True
    for line in " ".join(args).split("\n"):
        print("[!]", line)


def log_exception():
    traceback.print_exc()


class UpdateAlreadyInProgressError(Exception):
    """The update lock was already taken when take_update_lock was called."""


class UpdateNotInProgressError(Exception):
    """The update lock was not taken when release_update_lock was called."""


def take_update_lock():
    try:
        os.mkdir(UPDATE_LOCK_PATH)
    except OSError as e:
        if e.errno == errno.EEXIST and os.path.isdir(UPDATE_LOCK_PATH):
            raise UpdateAlreadyInProgressError
        else:
            raise e


def release_update_lock():
    try:
        os.rmdir(UPDATE_LOCK_PATH)
    except OSError as e:
        if e.errno == errno.ENOENT:  # No such file or directory
            raise UpdateNotInProgressError
        else:
            raise e


@contextlib.contextmanager
def update_lock():
    take_update_lock()
    try:
        yield
    except Exception:
        bug("Exception occurred during locked section!")
        bug()
        bug("The updater encountered an error during the update.")
        bug("Your robot may no longer function correctly.")
        bug("Contact Hills Road RoboCon for advice on how to proceed.")
        bug()
        bug("Please provide the entirety of this log, including the following debugging information.")
        bug()
        bug("Traceback from last exception:")
        log_exception()
        bug("Debugging information ends.")
    else:
        release_update_lock()


def git_pull(dest, source):
    try:
        subprocess.check_output(["git", "stash", "save"], cwd=dest)
        subprocess.check_output(["git", "checkout", "master"], cwd=dest)
        subprocess.check_output(["git", "pull", "--ff-only", source], cwd=dest)
    except subprocess.CalledProcessError as e:
        error("Command", repr(" ".join(e.cmd)), "failed with error code", e.returncode)
        error("Command output:", e.output)
        return False
    else:
        return True


def do_update():
    info("Creating USB mount point...")
    try:
        os.mkdir(USB_MOUNT_POINT)
    except OSError as e:
        if e.errno == errno.EEXIST:
            info("Mount point already exists!")
            if not os.path.isdir(USB_MOUNT_POINT):
                error("Mount point is not a directory!")
                return False
        else:
            raise
    else:
        info("Done USB mount point creation.")

    info("Updating fstab...")
    with open("/etc/fstab", "r") as fstab:
        fstab_update_needed = FSTAB_UPDATE_COMMENT not in fstab.read()
    if fstab_update_needed:
        with open("/etc/fstab", "a") as fstab:
            fstab.write("/dev/sda1  /media/RobotUSB  vfat,auto  nofail,auto  0  3\n")
            fstab.write(FSTAB_UPDATE_COMMENT + "\n")
        info("Done fstab update.")
    else:
        info("fstab update not needed!")

    # Git doesn't let us stash if we don't give it a name and email.
    info("Ensuring Git is configured correctly...")
    os.environ["HOME"] = "/root"  # Ew ew ew
    subprocess.check_output(["git", "config", "--global", "user.email", "brain-box@hr-robocon.org"])
    subprocess.check_output(["git", "config", "--global", "user.name", "Hills Road RoboCon"])
    info("Done Git configuration.")

    info("Updating sr.robot...")
    sr_robot_version = subprocess.check_output(["git", "describe", "--always", "--dirty", "--long"], cwd=SR_ROBOT_PATH)
    info("Currently at version {}.".format(sr_robot_version))
    new_sr_robot_path = os.path.join(USER_CODE_PATH, "sr-robot.git")
    if not git_pull(SR_ROBOT_PATH, new_sr_robot_path):
        return False
    sr_robot_version = subprocess.check_output(["git", "describe", "--always", "--dirty", "--long"], cwd=SR_ROBOT_PATH)
    info("Done sr.robot update (sr.robot is now at {}).".format(sr_robot_version))

    info("Updating Shepherd...")
    shepherd_version = subprocess.check_output(["git", "describe", "--always", "--dirty", "--long"], cwd=SHEPHERD_PATH)
    info("Currently at version {}.".format(shepherd_version))
    new_shepherd_path = os.path.join(USER_CODE_PATH, "shepherd.git")
    if not git_pull(SHEPHERD_PATH, new_shepherd_path):
        return False
    shepherd_version = subprocess.check_output(["git", "describe", "--always", "--dirty", "--long"], cwd=SHEPHERD_PATH)
    info("Done Shepherd update (Shepherd is now at {}).".format(shepherd_version))

    info("Done!")
    return True


def wait_for_start(fifo):
    with open(fifo, "r") as f:
        json_data = f.read()
    return json.loads(json_data)


def main():
    print("Hills Road RoboCon update 1")

    parser = argparse.ArgumentParser()
    parser.add_argument("--startfifo", dest="fifo")
    args, _ = parser.parse_known_args()

    # NB: due to issues that we're (hopefully) fixing in this update, we
    # must avoid doing anything that can't be interrupted (e.g. writing
    # to the filesystem) before the round starts.

    info("Checking for changes that may be overwritten by update.")
    ETC_PASSWD_HASH = "e6faef5d4a03d2c0f5f9c250b0ff6049eeee9d88dcb9d4a7d74d180ed9d004f5"
    with open("/etc/passwd", "r") as f:
        if hashlib.sha256(f.read()).hexdigest().lower() != ETC_PASSWD_HASH:
            error("Modification detected! Proceeding with the update could overwrite your changes!")
            sys.exit()

    info("Ready to begin update.")
    info("You must only start this update immediately after a reboot!")
    info("Waiting for start.")
    round_info = wait_for_start(args.fifo)
    info("Started! (Data from fifo: {!r})".format(round_info))

    success = None
    try:
        with update_lock():
            success = do_update()
    except UpdateAlreadyInProgressError:
        error("An update is either already in progress or did not complete successfully!")
    except UpdateNotInProgressError:
        bug("Update lock released when not held!")
        bug("This is probably an issue with the updater.")
    except Exception:
        bug("Unexpected exception raised in context manager:")
        log_exception()

    if code_is_buggy or success is None:
        bug("There may have been problems during the update, please send your logs to Hills Road RoboCon!")

    if success:
        info("Update completed successfully. Please reboot the Raspberry Pi now.")
    else:
        info("Update did not complete successfully.")
        info("Contact Hills Road RoboCon for assistance, providing the full log from this update.")


if __name__ == "__main__":
    main()
