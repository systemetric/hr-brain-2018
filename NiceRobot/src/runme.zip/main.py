from nicerobot import *

find_cube()
