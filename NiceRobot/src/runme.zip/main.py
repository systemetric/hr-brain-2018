from nicerobot import *

find_cube()
succ()
find_bucket()
drop()

#
# turn(90)