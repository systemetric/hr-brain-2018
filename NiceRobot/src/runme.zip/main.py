from nicerobot import *

for i in range(0, 4):
    move(2)
    turn(90)
