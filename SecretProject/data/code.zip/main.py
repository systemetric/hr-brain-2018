from nicerobot import *
import time

for count in range(10):
  pass
