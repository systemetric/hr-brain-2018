from nicerobot import *
import time

