from nicerobot import *
import time

find_cube()
pickup_cube()
find_bucket()
drop()
